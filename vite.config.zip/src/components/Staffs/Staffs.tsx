import React from "react";

const Staffs = () => {
  return <div>Staffs</div>;
};

export default Staffs;
